<?php

echo"soy el archivo de formulario.php";

?>
