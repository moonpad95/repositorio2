<?php 
echo "soy el codigo del archivo index.php";
echo "estoy editando este archivo desde el github";


?>
